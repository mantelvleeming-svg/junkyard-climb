package com.junkyardclimb.game

import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.android.billingclient.api.*

class MainActivity : AppCompatActivity(), PurchasesUpdatedListener {
    private lateinit var webView: WebView
    private lateinit var billingClient: BillingClient
    private val productIds = listOf(
        "coins_2000", "coins_10000", "fuel_pack_5", "repair_pack_5", "remove_ads"
    )
    private val productDetails = mutableMapOf<String, ProductDetails>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(GameBridge(), "AndroidStore")

        billingClient = BillingClient.newBuilder(this)
            .setListener(this)
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
            )
            .build()
        connectBilling()
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun connectBilling() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() {}
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                }
            }
        })
    }

    private fun queryProducts() {
        val products = productIds.map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(products).build()
        billingClient.queryProductDetailsAsync(params) { _, result ->
            result.productDetailsList.forEach { detail ->
                productDetails[detail.productId] = detail
            }
        }
    }

    private fun launchPurchase(productId: String) {
        val details = productDetails[productId] ?: return
        val pdp = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(details)
            .build()
        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(pdp))
            .build()
        billingClient.launchBillingFlow(this, params)
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode != BillingClient.BillingResponseCode.OK || purchases == null) return
        purchases.forEach { purchase ->
            if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return@forEach
            val productId = purchase.products.firstOrNull() ?: return@forEach
            if (productId == "remove_ads") {
                if (!purchase.isAcknowledged) {
                    billingClient.acknowledgePurchase(
                        AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
                    ) { br -> if (br.responseCode == BillingClient.BillingResponseCode.OK) grant(productId) }
                } else grant(productId)
            } else {
                billingClient.consumeAsync(
                    ConsumeParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
                ) { br, _ -> if (br.responseCode == BillingClient.BillingResponseCode.OK) grant(productId) }
            }
        }
    }

    private fun grant(productId: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.onNativePurchase && window.onNativePurchase('${productId}')", null)
        }
    }

    inner class GameBridge {
        @JavascriptInterface fun purchase(productId: String) {
            runOnUiThread { launchPurchase(productId) }
        }

        @JavascriptInterface fun shareChallenge(distance: Int, time: String) {
            val text = "Ik reed ${distance} meter in Junkyard Climb (${time}). Kun jij verder?"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Junkyard Climb challenge")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(intent, "Daag een vriend uit"))
        }
    }
}
