JUNKYARD CLIMB - ANDROID PROTOTYPE

Basis: stabiele v8 Worlds & Repair HTML in een native Android WebView.
Target API: 36 (Android 16), zodat dit voldoet aan de Play Store-eis vanaf 31 augustus 2026.
Billing: Google Play Billing Library 8.0.0.

Play Console product-ID's die je moet aanmaken als IN-APP PRODUCT:
- coins_2000
- coins_10000
- fuel_pack_5
- repair_pack_5
- remove_ads

Belangrijk:
1. De echte betaalflow werkt pas nadat exact deze producten in Play Console zijn aangemaakt en geactiveerd.
2. Test betalingen via een Internal/Closed testing build uit Google Play; sideloaded APK's zijn niet geschikt als betrouwbare billingtest.
3. Dit prototype verwerkt aankopen lokaal. Voor echte omzet op schaal hoort aankoopvalidatie server-side te gebeuren.
4. Voor nieuwe persoonlijke Play Console-accounts (na 13-11-2023) is momenteel 12 testers / 14 dagen gesloten test nodig vóór productie.
5. De HTML-game in app/src/main/assets/index.html kan verder worden verbeterd zonder de Android-shell opnieuw te ontwerpen.
